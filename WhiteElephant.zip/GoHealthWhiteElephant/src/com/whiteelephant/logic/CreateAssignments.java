package com.whiteelephant.logic;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.whiteelephant.obj.*;

public class CreateAssignments {

	public static void main(String[] args){
		CreateAssignments ca=new CreateAssignments();
		String [] personIdList=ca.getPersonIdList();
		List<Person> personList=ca.initializePerson(personIdList);
		ca.dumpLogs(personList, "People giving gifts");
		List<Person> temporaryList=ca.duplicatePersonList(personList);
		List<Person> gettingList=ca.generateAssignments(personList,temporaryList);
		ca.dumpLogs(gettingList, "People getting gifts");
	}
	
	private  void dumpLogs(List<Person> personList, String message) {
		System.out.println(message);
		for(Person person:personList){
			System.out.print(person.getPersonId()+"\t");
		}
		System.out.print("\n");
	}

	public  List<Person> generateAssignments(List<Person> personList,
			List<Person> temporaryList) {
		List<Person> gettingList= new ArrayList<Person>();
		for(Person person:personList){
			temporaryList=cleanUpTemporaryList(temporaryList, gettingList, person);
			String personId=choseSomeone(temporaryList);
			temporaryList=addUpTemporaryList(temporaryList, gettingList, person);
			gettingList.add(new Person(personId,person));
		}
		return gettingList;
	}

	private List<Person> addUpTemporaryList(List<Person> temporaryList,
			List<Person> gettingList, Person person) {
		temporaryList.add(person);
		for(Person p:gettingList){
			temporaryList.add(p);
		}
		return temporaryList;
	
	}

	private List<Person> cleanUpTemporaryList(List<Person> temporaryList,
			List<Person> gettingList, Person person) {
		temporaryList.remove(person);
		for(Person p:gettingList){
			temporaryList.remove(p);
		}
		return temporaryList;
	}

	private  String choseSomeone(List<Person> temporaryList) {
		Random rand=new Random();
		int randomInt=rand.nextInt(temporaryList.size());
		return temporaryList.get(randomInt).getPersonId();
	}

	public  List<Person> duplicatePersonList(List<Person> personList) {
		List<Person> duplicateList= new ArrayList<Person>(personList);
		return duplicateList;
	}

	private  String[] getPersonIdList() {
		return new String[]{ "Kyle", "Kenny", "Eric", 
				"Stan", "Stewie", "Brian" };
	}

	public  List<Person> initializePerson(String [] personIdList){
		List<Person> personList=new ArrayList<Person>();
		for(String personId:personIdList){
			personList.add(new Person(personId));
		}
		return personList;
	}	
}
