package com.whiteelephant.logic;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.whiteelephant.obj.Person;

public class CreateAssignmentsTest {

	@Test
	public void testGenerateAssignments() {
		Person p1=new Person("Rakesh");
		Person p2=new Person("Ganta");
		List<Person> givingList=new ArrayList<Person>();
		givingList.add(p1);
		givingList.add(p2);
		List<Person> duplicateList=new ArrayList<Person>();
		duplicateList.add(p1);
		duplicateList.add(p2);
		CreateAssignments createAssignments= new CreateAssignments();
		assertEquals(duplicateList, createAssignments.duplicatePersonList(givingList));
		List<Person> gettingList=createAssignments.generateAssignments(givingList, duplicateList);
		assertTrue(givingList.size()==gettingList.size());
	}

	@Test
	public void testDuplicatePersonList() {
		Person p1=new Person("Rakesh");
		Person p2=new Person("Ganta");
		List<Person> givingList=new ArrayList<Person>();
		givingList.add(p1);
		givingList.add(p2);
		List<Person> duplicateList=new ArrayList<Person>();
		duplicateList.add(p1);
		duplicateList.add(p2);
		CreateAssignments createAssignments= new CreateAssignments();
		assertEquals(duplicateList, createAssignments.duplicatePersonList(givingList));
	}
}
